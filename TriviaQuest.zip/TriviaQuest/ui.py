from tkinter import *
from tkinter import messagebox


from quiz_brain import QuizBrain
THEME_COLOR = "#375362"


class QuizzInterface:
    def __init__(self, quiz_brain: QuizBrain):

        self.message="""How to Play:

-Click the Tick Button (✔️) for Yes/True.
-Click the Cross Button (❌) for No/False.
-Your score updates after each answer.
-After 10 questions, your final score will be displayed.
-Close and relaunch the app for a new quiz set.

Enjoy the quiz!

Created By : Hari Ravendran.
"""

        self.quiz=quiz_brain
        self.window=Tk()
        self.window.title("Trivia Quest-The Quiz Game")
        self.window.config(padx=20,pady=20,bg=THEME_COLOR)

        self.score_label=Label(text="Score: 0", fg="white",bg=THEME_COLOR)
        self.score_label.grid(row=0,column=0,columnspan=2)

        self.canvas=Canvas(width=300,height=250, bg="white")
        self.question_text=self.canvas.create_text(150,125,width=280,text="Some Question", fill=THEME_COLOR, font=("Arial",14,"italic"))
        self.canvas.grid(row=1,column=0,columnspan=2,pady=50)

        true_img=PhotoImage(file="true.png")
        self.true_btn=Button(image=true_img,highlightthickness=0,command=self.on_click_true)
        self.true_btn.grid(row=2,column=0)

        false_img=PhotoImage(file="false.png")
        self.false_btn=Button(image=false_img,highlightthickness=0,command=self.on_click_false)
        self.false_btn.grid(row=2,column=1)

        self.help_btn = Button(text="Help", highlightthickness=0,command=self.on_click_help)
        self.help_btn.grid(row=3, column=0, columnspan=2, pady=20)

        self.get_next_question()

        self.window.mainloop()
    def on_click_help(self):
        messagebox.showinfo(title="Help", message=self.message)

    def on_click_true(self):
        is_right=self.quiz.check_answer("True")
        self.give_feedback(is_right)

    def on_click_false(self):
        is_right=self.quiz.check_answer("False")
        self.give_feedback(is_right)


    def get_next_question(self):
        self.canvas.config(bg="white")
        if self.quiz.still_has_questions():
            self.score_label.config(text=f"Score: {self.quiz.score}/10")
            q_text=self.quiz.next_question()
            self.canvas.itemconfig(self.question_text,text=q_text)
        else:
            self.true_btn.config(state="disabled")
            self.false_btn.config(state="disabled")
            self.canvas.itemconfig(self.question_text,text="Quiz Completed! Close and Re-launch this App for new set of questions.")

    def give_feedback(self,is_right):
        if is_right:
            self.canvas.config(bg="green")


        else:
            self.canvas.config(bg="red")


        self.window.after(1000,self.get_next_question)



